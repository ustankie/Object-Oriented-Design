package pl.edu.agh.internetshop.orderfilter;

public enum CompareType {
    EQUAL,
    GREATER,
    SMALLER,
    GEQ,
    SEQ
}
