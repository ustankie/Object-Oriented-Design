package rabaty;

public interface ObliczCenePoRabacie {
	double obliczCenePoRabacie(double cena);
}
