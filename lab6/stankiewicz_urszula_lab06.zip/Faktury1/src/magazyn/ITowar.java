package magazyn;

public interface ITowar {

    double getCena();
    void wypisz(int n);
}
