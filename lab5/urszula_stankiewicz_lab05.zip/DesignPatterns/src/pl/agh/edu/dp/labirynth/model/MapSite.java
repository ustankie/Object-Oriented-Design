package pl.agh.edu.dp.labirynth.model;

import pl.agh.edu.dp.labirynth.Player;

public abstract class MapSite {
    public abstract void Enter(Player player);
}
